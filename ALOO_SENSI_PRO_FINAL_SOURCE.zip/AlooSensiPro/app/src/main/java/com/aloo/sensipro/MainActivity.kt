package com.aloo.sensipro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.widget.LinearLayout
import android.view.ViewGroup
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONObject

/** Hosts assets/index.html and bridges it to the overlay service. */
class MainActivity : Activity() {
    companion object {
        private const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
        private const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
        private const val PREF_WALLET = "aloo_wallet"
        private const val KEY_CREDITS = "credits"
    }
    private lateinit var web: WebView
    private var rewardedAd: RewardedAd? = null
    private var adLoading = false
    private var bannerAd: AdView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        MobileAds.initialize(this) {}
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0A0C14"))
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0A0C14")) }
        layout.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val banner = AdView(this).apply {
            adUnitId = TEST_BANNER_AD_UNIT_ID
            setAdSize(AdSize.BANNER)
            loadAd(AdRequest.Builder().build())
        }
        bannerAd = banner
        layout.addView(banner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(layout)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                try {
                    if (u.scheme == "intent") {
                        val i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                        i.addCategory(Intent.CATEGORY_BROWSABLE)
                        i.component = null
                        i.selector = null
                        try { startActivity(i) } catch (e: Exception) {
                            i.getStringExtra("browser_fallback_url")?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
                        }
                    } else startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) { }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "AlooNative")
        OverlayService.onChange = { json ->
            runOnUiThread { web.evaluateJavascript("window.alooUpdate&&window.alooUpdate($json)", null) }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun sendRewardResult(earned: Boolean) {
        if (::web.isInitialized) runOnUiThread {
            web.evaluateJavascript("window.alooRewardResult&&window.alooRewardResult($earned)", null)
        }
    }

    private fun requestRewardedAd() {
        if (isFinishing || isDestroyed || adLoading) return
        rewardedAd?.let { ad ->
            rewardedAd = null
            ad.show(this) { sendRewardResult(true) }
            return
        }
        adLoading = true
        RewardedAd.load(this, TEST_REWARDED_AD_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { adLoading = false; rewardedAd = ad; requestRewardedAd() }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    adLoading = false
                    sendRewardResult(false)
                    Toast.makeText(this@MainActivity, "Test ad abhi available nahi hai", Toast.LENGTH_SHORT).show()
                }
            })
    }

    override fun onPause() { bannerAd?.pause(); super.onPause() }
    override fun onResume() { super.onResume(); bannerAd?.resume() }
    override fun onDestroy() {
        OverlayService.onChange = null
        bannerAd?.destroy(); bannerAd = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Opens a social page in the real app (tries every known package), then falls back to the browser. */
    private fun openSocial(kind: String) {
        val url: String
        val pkgs: List<String>
        if (kind == "tiktok") {
            url = "https://www.tiktok.com/@aloo.pc"
            pkgs = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go")
        } else {
            url = "https://www.youtube.com/@nexo4444-1"
            pkgs = listOf("com.google.android.youtube")
        }
        for (p in pkgs) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p))
                return
            } catch (e: ActivityNotFoundException) {
            } catch (e: Exception) {
            }
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Link open nahi hua: $url", Toast.LENGTH_LONG).show()
        }
    }

    inner class Bridge {
        @JavascriptInterface fun showRewardedAd() { runOnUiThread { requestRewardedAd() } }
        @JavascriptInterface fun getCredits(): Int = getSharedPreferences(PREF_WALLET, MODE_PRIVATE).getInt(KEY_CREDITS, 0)
        @JavascriptInterface fun addCredits(amount: Int): Int {
            val p = getSharedPreferences(PREF_WALLET, MODE_PRIVATE)
            val next = (p.getInt(KEY_CREDITS, 0) + amount.coerceIn(0, 5)).coerceAtMost(100000)
            p.edit().putInt(KEY_CREDITS, next).apply()
            return next
        }
        @JavascriptInterface fun launchGame(game: String): String {
            val pkg = if (game == "max") "com.dts.freefiremax" else "com.dts.freefireth"
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return "not_installed"
            val prefs = getSharedPreferences(PREF_WALLET, MODE_PRIVATE)
            val credits = prefs.getInt(KEY_CREDITS, 0)
            if (credits < 5) return "no_credits"
            prefs.edit().putInt(KEY_CREDITS, credits - 5).apply()
            return try { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); "ok" }
            catch (e: Exception) { prefs.edit().putInt(KEY_CREDITS, credits).apply(); "launch_failed" }
        }
        @JavascriptInterface fun hasPermission(): Boolean = Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface fun requestPermission() {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun openLink(kind: String) {
            runOnUiThread { openSocial(kind) }
        }

        /** Last config the overlay knew (it may have been edited from the floating menu while the app was closed). */
        @JavascriptInterface fun getState(): String = OverlayService.savedState(this@MainActivity)

        @JavascriptInterface fun menu(state: String) {
            runOnUiThread { OverlayService.instance?.setMenu(state) }
        }

        @JavascriptInterface fun sync(json: String) {
            runOnUiThread {
                OverlayService.save(this@MainActivity, json)
                if (!Settings.canDrawOverlays(this@MainActivity)) return@runOnUiThread
                val running = OverlayService.instance
                val any = try {
                    val o = JSONObject(json)
                    (o.optJSONObject("xh")?.optBoolean("on") ?: false) || (o.optJSONObject("mc")?.optBoolean("on") ?: false)
                } catch (e: Exception) { false }
                try {
                    if (running != null) running.applyConfig(json)
                    else if (any) {
                        val i = Intent(this@MainActivity, OverlayService::class.java).putExtra("cfg", json)
                        startForegroundService(i)
                    }
                } catch (e: Exception) { }
            }
        }
    }
}
